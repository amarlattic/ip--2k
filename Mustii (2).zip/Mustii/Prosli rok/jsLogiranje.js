const korisnici = [];

function validacija_ime_prezime(tekst) {
    if (!tekst.trim()) {
		document.getElementById('errorImePrezime').textContent = 'Unesite ime i prezime';
			return false;
        }
        document.getElementById('errorImePrezime').textContent = '';
			return true;
			
}

function validacija_email(email) {
    if (!email.trim()) {
        document.getElementById('errorEmail').textContent = 'Unesite email';
            return false;
    } else if (!email.includes('@')) {
            document.getElementById('errorEmail').textContent = 'Nepravilna mail adresa';
                return false;
        }
    document.getElementById('errorEmail').textContent = '';
        return true;
}

function validacija_kor_ime(tekst) {
    if (!tekst.trim() || tekst.includes(' ')) {
        document.getElementById('errorKorIme').textContent = 'Unesite validno korisničko ime';
            return false;
    }
    document.getElementById('errorKorIme').textContent = '';
        return true;
}

function validacija_lozinke(tekst) {
        if (!tekst.trim()) {
            document.getElementById('errorLozinka').textContent = 'Unesite lozinku';
                return false;
        }
        document.getElementById('errorLozinka').textContent = '';
            return true;
}

function validacija_potvrde_lozinke(lozinka, potvrda) {
    if (lozinka !== potvrda) {
		document.getElementById('errorPotvrdaLozinke').textContent = 'Potvrda se ne slaže sa lozinkom';
			return false;
	}
	document.getElementById('errorPotvrdaLozinke').textContent = '';
		return true;
}

function validacija_forme() {
	const imePrezime = document.getElementById('imePrezime').value;
	const email = document.getElementById('email').value;
	const korIme = document.getElementById('korIme').value;
	const lozinka = document.getElementById('lozinka').value;
	const potvrdaLozinke = document.getElementById('potvrdaLozinke').value;

	const validacijaIme = validacija_ime_prezime(imePrezime);
	const validacijaEmail = validacija_email(email);
	const validacijaKorIme = validacija_kor_ime(korIme);
	const validacijaLozinka = validacija_lozinke(lozinka);
	const validacijaPotvrda = validacija_potvrde_lozinke(lozinka, potvrdaLozinke);

	return validacijaIme && validacijaEmail && validacijaKorIme && validacijaLozinka && validacijaPotvrda;
}

function dodaj_korisnika() {
	if (!validacija_forme()) {
		return;
	}

	const imePrezime = document.getElementById('imePrezime').value;
	const email = document.getElementById('email').value;
	const korIme = document.getElementById('korIme').value;
	const lozinka = document.getElementById('lozinka').value;
	const uvjetPrihvacen = document.getElementById('uvjetPrihvacen').checked;

	const noviKorisnik = {
		imePrezime,
		email,
		korIme,
		lozinka,
		uvjetPrihvacen
	};

	korisnici.push(noviKorisnik);
	prikaziKorisnike();
	document.getElementById('registrationForm').reset();
}

function prikaziKorisnike() {
	const tabela = document.getElementById('korisniciTabela').querySelector('tbody');
	tabela.innerHTML = '';

	korisnici.forEach(korisnik => {
		const red = document.createElement('tr');
		if (!korisnik.uvjetPrihvacen) {
			red.classList.add('rejected');
		}

		red.innerHTML = `
		<td>${korisnik.imePrezime}</td>
		<td>${korisnik.email}</td>
		<td>${korisnik.korIme}</td>
		<td>${korisnik.uvjetPrihvacen ? 'Da' : 'Ne'}</td>
		`;
		tabela.appendChild(red);
	});
}

function ponisti_formu() {
	document.getElementById('registrationForm').reset();

	document.getElementById('errorImePrezime').textContent = '';
	document.getElementById('errorEmail').textContent = '';
	document.getElementById('errorKorIme').textContent = '';
	document.getElementById('errorLozinka').textContent = '';
	document.getElementById('errorPotvrdaLozinke').textContent = '';
	document.getElementById('errorUvjetPrihvacen').textContent = '';
}